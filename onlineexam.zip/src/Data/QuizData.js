export const QuizData = [
    {
        question: "2 + 2?",
        options:[ "2", "3", "6", "4"],
        answer: 4
    },
    {
        question: "5 x 5?",
        options:["20", "25", "5", "30"],
        answer: 2
    },
    {
        question: "What is the capital of India?",
        options: ["New Delhi", "Mumbai", "Agra", "Lucknow"],
        answer: 1
    },
    {
        question: "Republic day celebrated on?",
        options: ["15 Aug", "26 Jan", "2 Oct", "25 Dec"],
        answer:2
    },
];